package com.creek.catering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CateringApplicationTests {

	@Test
	void contextLoads() {
	}

}
