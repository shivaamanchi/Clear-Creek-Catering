package com.creek.catering.modals;

public class Toppings {
	
	public boolean avaialble;
	public int basePrice;

}
